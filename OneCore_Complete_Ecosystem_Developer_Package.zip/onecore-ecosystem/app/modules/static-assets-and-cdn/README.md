# Static Assets and CDN

Master specification category: **64**

## Source scope
cdn.onecore.co.ke and media.onecore.co.ke: approved public images/product assets/logos/icons/fonts/CSS/JS/downloads; thumbnails/WebP/AVIF/responsive sizes/cache/invalidation/versioning/compression/bandwidth/analytics/integrity/deployment/SSL/cache purge/SVG sanitization/CSP; private files excluded.

## Implementation status
Scaffold only. This folder reserves the domain boundary; it is not a claim of production implementation.

## Required implementation
- Define domain entities, constraints, indexes and migrations.
- Add domain services and versioned API routes.
- Enforce tenant, branch and role authorization at the service layer.
- Add validation, approval workflows, audit events and idempotency where needed.
- Build responsive user/admin workflows and accessible states.
- Add unit, integration, security and end-to-end tests.
- Add monitoring, retention, backup/restore and operational documentation.
- Complete sandbox/UAT and release approval for external dependencies.
